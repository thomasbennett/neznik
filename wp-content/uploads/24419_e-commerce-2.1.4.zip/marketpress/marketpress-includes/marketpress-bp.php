<?php
/*
MarketPress BP Features
*/

class MarketPress_BP {

	function MarketPress_BP() {
		$this->__construct();
	}
	
  function __construct() {


	}

  function install() {

  }

}
$mp_bp = &new MarketPress_BP();

?>